<?php
include("phpwikibot.php"); 
$username=""; //your username
$password=""; //your password
$wiki='it'; //prefix your wiki
$epm=5; //edit per minute
$lag=5; //max lag with server
$bot=new phpwikibot($username, $password, $wiki, $epm, $lag);
?>

